//
//  Day.m
//  Lunisolar
//
//  Created by Haley Smith on 3/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Day.h"

@implementation Day

- (id) initWithParams:(int)day month:(int)month{
    self = [super init];
    
	if (self){
        self->day = day;
        self->month = month;
	}
	
	return self;
}


@end
