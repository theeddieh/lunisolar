//
//  Week.m
//  Lunisolar
//
//  Created by Haley Smith on 3/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Week.h"

@implementation Week

- (id) initWithParams:(int)weekNumber days:(NSMutableArray *)days{

	self = [super init];

	if (self){
        self->weekNumber = weekNumber;
        self->days = days;
	}
	
	return self;
}
@end
