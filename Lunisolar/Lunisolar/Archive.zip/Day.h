//
//  Day.h
//  Lunisolar
//
//  Created by Haley Smith on 3/9/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Day : NSObject{
    
   	int weekDay;
    int day;
    int month;
}

- (id) initWithParams:(int)day month:(int)month;

@end
