//
//  CircularViewController.h
//  Lunisolar
//
//  Created by Haley Smith on 4/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PickerViewController.h"

@interface CircularViewController : UIViewController<UIPopoverControllerDelegate>

-(IBAction)plusButtonPressed:(id)sender;

-(IBAction)minusButtonPressed:(id)sender;

@end
